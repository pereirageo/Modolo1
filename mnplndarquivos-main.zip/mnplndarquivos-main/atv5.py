nome = input("Digite o numero: ")
email = input("digite o e-mail: ")

with open("frutas.txt", "a") as arquivo:
    arquivo.write(nome + " | " + email + "\n")
