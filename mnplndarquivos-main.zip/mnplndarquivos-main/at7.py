lista = ['python', 'java', 'c++']

removido = lista.pop('java')

print(removido)

