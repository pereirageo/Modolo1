frutas = input ("Banana, Maçã e Laranja")

with open ("frutas.txt", "a") as arquivo:
    arquivo.write(frutas)