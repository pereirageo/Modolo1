lista = ['a', 'b', 'd']

lista . insert(2, 'c')

lista . remove ('a')

print(lista)

