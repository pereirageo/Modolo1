lista = ["-5", "-4", "-4", "-3","-2","-1", "0"]

lista . append ("1")
lista . append ("2")
lista . append ("3")
lista . append ("4")
lista . append ("5")

print(lista)

