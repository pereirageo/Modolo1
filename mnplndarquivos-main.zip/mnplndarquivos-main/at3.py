lista = ['a', 'b', 'c']

lista[1] = "x"

print (lista)
