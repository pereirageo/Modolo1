lista = [100, 200, 300, 400]

removido = lista.pop(3)

print(removido)