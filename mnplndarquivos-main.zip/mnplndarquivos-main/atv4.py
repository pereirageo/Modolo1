
try:
    with open("jogos.txt", "r") as arquivo:
        print(arquivo.read())

except:
    with open ("jogos.txt", "a") as arquivo:
        arquivo.write()