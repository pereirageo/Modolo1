

with open("frutas.txt", "r") as arquivo:
    print(arquivo.read())

