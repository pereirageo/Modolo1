import pyautogui

pyautogui.press('win')
pyautogui.write('Google Chrome')
pyautogui.press('enter')

pyautogui.moveTo(1450,130,duration=3)
pyautogui.click()
