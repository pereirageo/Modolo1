palavra = input ("digite uma palavra:")

for item in palavra:
    print(item)
    if item in ' aeiou':
        print ("é vogal")
    else:
        print("não é vogal")