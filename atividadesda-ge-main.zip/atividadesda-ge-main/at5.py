palavra = input ("digite sua palavra:")
for letra in palavra:
    print(letra)