numero = 5 

for i in range (1,11):
    print(f" {i} x {numero} = {i * numero}")
