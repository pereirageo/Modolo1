numeros = 1,20

for i in range (1,20):
    if i %2 == 0:
        print(i)