compras = [ "arroz", "feijão", "leite", "pão"]

for item in compras:
    print(item)
    