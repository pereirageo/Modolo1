alunos = ["jose", "marcielly", "geovanna"]

for item in alunos:
    print(item)
    nota1=int (input("digite sua nota"))
    nota2=int (input("digite sua nota"))
    nota3=int (input("digite sua nota"))
    media=(nota1+nota2+nota3) / 3
    print(media)