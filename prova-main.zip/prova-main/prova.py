nome = input(" Digite sua nome ")

peso = int(input("Digite seu peso "))

altura = float(input("Digite sua altura "))

imc = peso/(altura*altura)

if imc <=18.5:
    print(peso, "Abaixo do peso")
elif imc<=19.0:
    print(peso, "Peso normal")
elif imc<=25.0:
    print(peso, "Sobrepeso")
elif imc <=30.0:
    print(peso, "Obesidade grau 1")
elif imc <= 35.0:
    print(peso, "Obesidade grau 2")
else :
    print(peso, "Obesidade grau 3")